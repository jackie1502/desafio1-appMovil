import {
  Injectable,
  Observable,
  fromEvent,
  setClassMetadata,
  ɵɵdefineInjectable,
  ɵɵgetInheritedFactory
} from "./chunk-YI3QFCWV.js";
import "./chunk-WDMUDEB6.js";

// node_modules/@awesome-cordova-plugins/core/bootstrap.js
function checkReady() {
  if (typeof process === "undefined") {
    const win = typeof window !== "undefined" ? window : {};
    const DEVICE_READY_TIMEOUT = 5e3;
    const before = Date.now();
    let didFireReady = false;
    win.document.addEventListener("deviceready", () => {
      console.log(`Ionic Native: deviceready event fired after ${Date.now() - before} ms`);
      didFireReady = true;
    });
    setTimeout(() => {
      if (!didFireReady && win.cordova) {
        console.warn(`Ionic Native: deviceready did not fire within ${DEVICE_READY_TIMEOUT}ms. This can happen when plugins are in an inconsistent state. Try removing plugins from plugins/ and reinstalling them.`);
      }
    }, DEVICE_READY_TIMEOUT);
  }
}

// node_modules/@awesome-cordova-plugins/core/decorators/common.js
var ERR_CORDOVA_NOT_AVAILABLE = { error: "cordova_not_available" };
var ERR_PLUGIN_NOT_INSTALLED = { error: "plugin_not_installed" };
function getPromise(callback) {
  const tryNativePromise = () => {
    if (Promise) {
      return new Promise((resolve, reject) => {
        callback(resolve, reject);
      });
    } else {
      console.error("No Promise support or polyfill found. To enable Ionic Native support, please add the es6-promise polyfill before this script, or run with a library like Angular or on a recent browser.");
    }
  };
  if (typeof window !== "undefined" && window.angular) {
    const doc = window.document;
    const injector = window.angular.element(doc.querySelector("[ng-app]") || doc.body).injector();
    if (injector) {
      const $q = injector.get("$q");
      return $q((resolve, reject) => {
        callback(resolve, reject);
      });
    }
    console.warn(`Angular 1 was detected but $q couldn't be retrieved. This is usually when the app is not bootstrapped on the html or body tag. Falling back to native promises which won't trigger an automatic digest when promises resolve.`);
  }
  return tryNativePromise();
}
function wrapPromise(pluginObj, methodName, args, opts = {}) {
  let pluginResult, rej;
  const p = getPromise((resolve, reject) => {
    if (opts.destruct) {
      pluginResult = callCordovaPlugin(pluginObj, methodName, args, opts, (...args2) => resolve(args2), (...args2) => reject(args2));
    } else {
      pluginResult = callCordovaPlugin(pluginObj, methodName, args, opts, resolve, reject);
    }
    rej = reject;
  });
  if (pluginResult && pluginResult.error) {
    p.catch(() => {
    });
    typeof rej === "function" && rej(pluginResult.error);
  }
  return p;
}
function wrapOtherPromise(pluginObj, methodName, args, opts = {}) {
  return getPromise((resolve, reject) => {
    const pluginResult = callCordovaPlugin(pluginObj, methodName, args, opts);
    if (pluginResult) {
      if (pluginResult.error) {
        reject(pluginResult.error);
      } else if (pluginResult.then) {
        pluginResult.then(resolve).catch(reject);
      }
    } else {
      reject({ error: "unexpected_error" });
    }
  });
}
function wrapObservable(pluginObj, methodName, args, opts = {}) {
  return new Observable((observer) => {
    let pluginResult;
    if (opts.destruct) {
      pluginResult = callCordovaPlugin(pluginObj, methodName, args, opts, (...args2) => observer.next(args2), (...args2) => observer.error(args2));
    } else {
      pluginResult = callCordovaPlugin(pluginObj, methodName, args, opts, observer.next.bind(observer), observer.error.bind(observer));
    }
    if (pluginResult && pluginResult.error) {
      observer.error(pluginResult.error);
      observer.complete();
    }
    return () => {
      try {
        if (opts.clearFunction) {
          if (opts.clearWithArgs) {
            return callCordovaPlugin(pluginObj, opts.clearFunction, args, opts, observer.next.bind(observer), observer.error.bind(observer));
          }
          return callCordovaPlugin(pluginObj, opts.clearFunction, []);
        }
      } catch (e) {
        console.warn("Unable to clear the previous observable watch for", pluginObj.constructor.getPluginName(), methodName);
        console.warn(e);
      }
    };
  });
}
function wrapEventObservable(event, element) {
  element = typeof window !== "undefined" && element ? get(window, element) : element || (typeof window !== "undefined" ? window : {});
  return fromEvent(element, event);
}
function checkAvailability(plugin, methodName, pluginName) {
  let pluginRef, pluginPackage;
  if (typeof plugin === "string") {
    pluginRef = plugin;
  } else {
    pluginRef = plugin.constructor.getPluginRef();
    pluginName = plugin.constructor.getPluginName();
    pluginPackage = plugin.constructor.getPluginInstallName();
  }
  const pluginInstance = getPlugin(pluginRef);
  if (!pluginInstance || !!methodName && typeof pluginInstance[methodName] === "undefined") {
    if (typeof window === "undefined" || !window.cordova) {
      cordovaWarn(pluginName, methodName);
      return ERR_CORDOVA_NOT_AVAILABLE;
    }
    pluginWarn(pluginName, pluginPackage, methodName);
    return ERR_PLUGIN_NOT_INSTALLED;
  }
  return true;
}
function setIndex(args, opts = {}, resolve, reject) {
  if (opts.sync) {
    return args;
  }
  if (opts.callbackOrder === "reverse") {
    args.unshift(reject);
    args.unshift(resolve);
  } else if (opts.callbackStyle === "node") {
    args.push((err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result);
      }
    });
  } else if (opts.callbackStyle === "object" && opts.successName && opts.errorName) {
    const obj = {};
    obj[opts.successName] = resolve;
    obj[opts.errorName] = reject;
    args.push(obj);
  } else if (typeof opts.successIndex !== "undefined" || typeof opts.errorIndex !== "undefined") {
    const setSuccessIndex = () => {
      if (opts.successIndex > args.length) {
        args[opts.successIndex] = resolve;
      } else {
        args.splice(opts.successIndex, 0, resolve);
      }
    };
    const setErrorIndex = () => {
      if (opts.errorIndex > args.length) {
        args[opts.errorIndex] = reject;
      } else {
        args.splice(opts.errorIndex, 0, reject);
      }
    };
    if (opts.successIndex > opts.errorIndex) {
      setErrorIndex();
      setSuccessIndex();
    } else {
      setSuccessIndex();
      setErrorIndex();
    }
  } else {
    args.push(resolve);
    args.push(reject);
  }
  return args;
}
function callCordovaPlugin(pluginObj, methodName, args, opts = {}, resolve, reject) {
  args = setIndex(args, opts, resolve, reject);
  const availabilityCheck = checkAvailability(pluginObj, methodName);
  if (availabilityCheck === true) {
    const pluginInstance = getPlugin(pluginObj.constructor.getPluginRef());
    return pluginInstance[methodName].apply(pluginInstance, args);
  } else {
    return availabilityCheck;
  }
}
function getPlugin(pluginRef) {
  if (typeof window !== "undefined") {
    return get(window, pluginRef);
  }
  return null;
}
function get(element, path) {
  const paths = path.split(".");
  let obj = element;
  for (let i = 0; i < paths.length; i++) {
    if (!obj) {
      return null;
    }
    obj = obj[paths[i]];
  }
  return obj;
}
function pluginWarn(pluginName, plugin, method) {
  if (method) {
    console.warn("Native: tried calling " + pluginName + "." + method + ", but the " + pluginName + " plugin is not installed.");
  } else {
    console.warn(`Native: tried accessing the ${pluginName} plugin but it's not installed.`);
  }
  if (plugin) {
    console.warn(`Install the ${pluginName} plugin: 'ionic cordova plugin add ${plugin}'`);
  }
}
function cordovaWarn(pluginName, method) {
  if (typeof process === "undefined") {
    if (method) {
      console.warn("Native: tried calling " + pluginName + "." + method + ", but Cordova is not available. Make sure to include cordova.js or run in a device/simulator");
    } else {
      console.warn("Native: tried accessing the " + pluginName + " plugin but Cordova is not available. Make sure to include cordova.js or run in a device/simulator");
    }
  }
}
var wrap = (pluginObj, methodName, opts = {}) => {
  return (...args) => {
    if (opts.sync) {
      return callCordovaPlugin(pluginObj, methodName, args, opts);
    } else if (opts.observable) {
      return wrapObservable(pluginObj, methodName, args, opts);
    } else if (opts.eventObservable && opts.event) {
      return wrapEventObservable(opts.event, opts.element);
    } else if (opts.otherPromise) {
      return wrapOtherPromise(pluginObj, methodName, args, opts);
    } else {
      return wrapPromise(pluginObj, methodName, args, opts);
    }
  };
};

// node_modules/@awesome-cordova-plugins/core/util.js
function get2(element, path) {
  const paths = path.split(".");
  let obj = element;
  for (let i = 0; i < paths.length; i++) {
    if (!obj) {
      return null;
    }
    obj = obj[paths[i]];
  }
  return obj;
}

// node_modules/@awesome-cordova-plugins/core/awesome-cordova-plugin.js
var AwesomeCordovaNativePlugin = class {
  static pluginName = "";
  static pluginRef = "";
  static plugin = "";
  static repo = "";
  static platforms = [];
  static install = "";
  /**
   * Returns a boolean that indicates whether the plugin is installed
   *
   * @returns {boolean}
   */
  static installed() {
    const isAvailable = checkAvailability(this.pluginRef) === true;
    return isAvailable;
  }
  /**
   * Returns the original plugin object
   */
  static getPlugin() {
    if (typeof window !== "undefined") {
      return get2(window, this.pluginRef);
    }
    return null;
  }
  /**
   * Returns the plugin's name
   */
  static getPluginName() {
    const pluginName = this.pluginName;
    return pluginName;
  }
  /**
   * Returns the plugin's reference
   */
  static getPluginRef() {
    const pluginRef = this.pluginRef;
    return pluginRef;
  }
  /**
   * Returns the plugin's install name
   */
  static getPluginInstallName() {
    const plugin = this.plugin;
    return plugin;
  }
  /**
   * Returns the plugin's supported platforms
   */
  static getSupportedPlatforms() {
    const platform = this.platforms;
    return platform;
  }
};

// node_modules/@awesome-cordova-plugins/core/decorators/cordova.js
function cordova(pluginObj, methodName, config, args) {
  return wrap(pluginObj, methodName, config).apply(this, args);
}

// node_modules/@awesome-cordova-plugins/core/index.js
checkReady();

// node_modules/@awesome-cordova-plugins/flashlight/ngx/index.js
var Flashlight = class _Flashlight extends AwesomeCordovaNativePlugin {
  available() {
    return cordova(this, "available", {}, arguments);
  }
  switchOn() {
    return cordova(this, "switchOn", {}, arguments);
  }
  switchOff() {
    return cordova(this, "switchOff", {}, arguments);
  }
  toggle() {
    return cordova(this, "toggle", {}, arguments);
  }
  isSwitchedOn() {
    return cordova(this, "isSwitchedOn", {
      "sync": true
    }, arguments);
  }
  static ɵfac = /* @__PURE__ */ (() => {
    let ɵFlashlight_BaseFactory;
    return function Flashlight_Factory(__ngFactoryType__) {
      return (ɵFlashlight_BaseFactory || (ɵFlashlight_BaseFactory = ɵɵgetInheritedFactory(_Flashlight)))(__ngFactoryType__ || _Flashlight);
    };
  })();
  static ɵprov = ɵɵdefineInjectable({
    token: _Flashlight,
    factory: _Flashlight.ɵfac
  });
  static pluginName = "Flashlight";
  static plugin = "cordova-plugin-flashlight";
  static pluginRef = "window.plugins.flashlight";
  static repo = "https://github.com/EddyVerbruggen/Flashlight-PhoneGap-Plugin";
  static platforms = ["Android", "iOS", "Windows Phone 8"];
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Flashlight, [{
    type: Injectable
  }], null, {
    available: [],
    switchOn: [],
    switchOff: [],
    toggle: [],
    isSwitchedOn: []
  });
})();
export {
  Flashlight
};
//# sourceMappingURL=@awesome-cordova-plugins_flashlight_ngx.js.map
