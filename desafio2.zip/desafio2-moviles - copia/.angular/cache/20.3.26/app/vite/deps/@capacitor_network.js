import {
  registerPlugin
} from "./chunk-6N3Y4XHO.js";
import "./chunk-WDMUDEB6.js";

// node_modules/@capacitor/network/dist/esm/index.js
var Network = registerPlugin("Network", {
  web: () => import("./web-457SZL3U.js").then((m) => new m.NetworkWeb())
});
export {
  Network
};
//# sourceMappingURL=@capacitor_network.js.map
