import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonText,
  ToastController
} from '@ionic/angular/standalone';

import { Network, ConnectionStatus } from '@capacitor/network';
import { PluginListenerHandle } from '@capacitor/core';
import { Flashlight } from '@awesome-cordova-plugins/flashlight/ngx';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonButton,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonText
  ],
})
export class HomePage implements OnInit, OnDestroy {

  estadoConexion: string = '';
  tipoConexion: string = '';
  private networkListener?: PluginListenerHandle;

  constructor(
    private toastController: ToastController,
    private flashlight: Flashlight
  ) {}

  async ngOnInit() {
    const status = await Network.getStatus();

    await this.mostrarEstadoConexion(status);
    await this.parpadearLinterna();

    this.networkListener = await Network.addListener(
      'networkStatusChange',
      async (status: ConnectionStatus) => {
        await this.mostrarEstadoConexion(status);
        await this.parpadearLinterna();
      }
    );
  }

  async mostrarEstadoConexion(status: ConnectionStatus) {
    this.estadoConexion = status.connected ? 'Conectado' : 'Desconectado';
    this.tipoConexion = status.connectionType;

    const mensaje = status.connected
      ? `Estado: Conectado | Tipo de conexión: ${status.connectionType}`
      : `Estado: Desconectado | Tipo de conexión: ${status.connectionType}`;

    const toast = await this.toastController.create({
      message: mensaje,
      duration: 3000,
      position: 'bottom'
    });

    await toast.present();
  }

  async parpadearLinterna() {
    try {
      for (let i = 0; i < 3; i++) {
        await this.flashlight.switchOn();
        await this.esperar(500);

        await this.flashlight.switchOff();
        await this.esperar(500);
      }
    } catch (error) {
      console.log('La linterna solo funciona en dispositivo real.', error);
    }
  }

  esperar(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async ngOnDestroy() {
    if (this.networkListener) {
      await this.networkListener.remove();
    }
  }
}