import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonIcon,
  ToastController
} from '@ionic/angular/standalone';

import { Flashlight } from '@awesome-cordova-plugins/flashlight/ngx';
import { addIcons } from 'ionicons';
import { flash, flashOff, home } from 'ionicons/icons';

@Component({
  selector: 'app-linterna',
  templateUrl: './linterna.page.html',
  styleUrls: ['./linterna.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonButton,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonIcon
  ],
})
export class LinternaPage {

  linternaEncendida: boolean = false;

  constructor(
    private flashlight: Flashlight,
    private toastController: ToastController
  ) {
    addIcons({
      flash,
      flashOff,
      home
    });
  }

  async controlarLinterna() {
    try {
      if (this.linternaEncendida) {
        await this.flashlight.switchOff();
        this.linternaEncendida = false;
        await this.mostrarMensaje('Linterna apagada');
      } else {
        await this.flashlight.switchOn();
        this.linternaEncendida = true;
        await this.mostrarMensaje('Linterna encendida');
      }
    } catch (error) {
      await this.mostrarMensaje('La linterna solo funciona en un dispositivo real.');
      console.log(error);
    }
  }

  async mostrarMensaje(mensaje: string) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 2000,
      position: 'bottom'
    });

    await toast.present();
  }
}